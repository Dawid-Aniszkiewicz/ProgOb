import java.util.HashMap;

public class Magazyn {

    private HashMap<Produkt, Integer> produktyNaMagazynie = new HashMap<Produkt, Integer>();

    public HashMap<Produkt, Integer> getProduktyNaMagazynie() {
        return produktyNaMagazynie;
    }

    public void setProduktyNaMagazynie(HashMap<Produkt, Integer> produktyNaMagazynie) {
        this.produktyNaMagazynie = produktyNaMagazynie;
    }

    public Magazyn(Produkt p){
        produktyNaMagazynie.put(p, p.getIloscNaMagazynie());
    }

    @Override
    public String toString() {
        StringBuilder tekst = new StringBuilder();
        for (Produkt item : produktyNaMagazynie.keySet()) {
            tekst.append("przedmiot: ").append(item.getNazwa()).append(", ").append(produktyNaMagazynie.get(item)).append("\n");
        }
        return tekst.toString();
    }
    public void dodajProdukt(Produkt singleProduct){
        produktyNaMagazynie.put(singleProduct, singleProduct.getIloscNaMagazynie());
    }
}
