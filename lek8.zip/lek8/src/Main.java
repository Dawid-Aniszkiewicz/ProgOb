public class Main {
    public static void main(String[] args) {
        var jablko = new Produkt("jablko",12.50,20);
        var banan = new Produkt("banan",2.50,12);
        // zad 1
        /*
        monitor.wyswietlInformacje();
        monitor.dodajDoMagazynu(1);
        monitor.wyswietlInformacje();
        System.out.println();
        monitor.usunZMagazynu(15);
        monitor.wyswietlInformacje();
        System.out.println();
        monitor.usunZMagazynu(2);
        monitor.wyswietlInformacje();
        */
/*
        var koszyk = new KoszykZakupowy();
        koszyk.dodajProdukt(jablko,1);
        koszyk.dodajProdukt(banan,2);
        koszyk.dodajProdukt(jablko,3);

        var koszyk2 = new KoszykZakupowy();
        koszyk2.dodajProdukt(jablko,5);
//        koszyk.wyswietlZawartoscKoszyka();
        System.out.println(koszyk.obliczCalkowitaWartosc());

        System.out.println();

        var order = new Zamowienie(koszyk,"W drodze");
        order.wyswietlZamowienie();
        System.out.println();
        var order2 = new Zamowienie(koszyk2,"zagubione");


        var listaZamowieniowa = new ArrayList<Zamowienie>();
        listaZamowieniowa.add(order);
        listaZamowieniowa.add(order2);


        var osoba = new Klient("Jan","Kowalski", listaZamowieniowa);
        osoba.wyswietlHistorieZamowien();
        System.out.println(osoba.obliczLacznyKosztZamowien());

//        System.out.println(monitor.iloscNaMagazynie);
        var sklepik = new Sklep(new ArrayList<Produkt>());
*/

        Magazyn magazynSklepu = new Magazyn(jablko);
        magazynSklepu.dodajProdukt(banan);
        System.out.println(magazynSklepu.toString());



    }

}