interface AdresINT{

}
