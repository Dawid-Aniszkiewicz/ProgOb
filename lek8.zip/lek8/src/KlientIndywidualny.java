import java.util.ArrayList;
import java.util.List;

public class KlientIndywidualny extends Klient {
    final String pesel;

    public KlientIndywidualny(String imie, String nazwisko, List<Zamowienie> listaZamowien, Adres adresKlienta, String pesel) {
        super(imie,nazwisko, (ArrayList<Zamowienie>) listaZamowien, adresKlienta);
        this.pesel=pesel;
    }
}
