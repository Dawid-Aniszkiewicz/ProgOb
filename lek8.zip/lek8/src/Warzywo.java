public abstract class Warzywo {

    public abstract void Smak();
    public abstract void Umyj();
    public abstract void Zjedz();


}



//class Marchew extends Warzywo {
//    public void Smak() {
//        System.out.println("Marchew smak");
//    }
//
//    public void Umyj() {
//        System.out.println("Umyj Marchew");
//    }
//
//    public void Zjedz() {
//        System.out.println("Zjedz Marchew");
//    }
//}
class main2 {
    public static void main(String[] args) {
       // Warzywo marchew = new Marchew();
       // marchew.Smak();
       // marchew.Umyj();
       // marchew.Zjedz();
    }
}
