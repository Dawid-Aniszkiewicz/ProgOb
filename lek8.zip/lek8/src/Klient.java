import java.util.ArrayList;
import java.util.Objects;

public class Klient {

    public String imie;
    public String nazwisko;
    public ArrayList<Zamowienie> listaZamowien;
    public Adres adresKlienta;

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public ArrayList<Zamowienie> getListaZamowien() {
        return listaZamowien;
    }

    public void setListaZamowien(ArrayList<Zamowienie> listaZamowien) {
        this.listaZamowien = listaZamowien;
    }

    public Adres getAdresKlienta() {
        return adresKlienta;
    }

    public void setAdresKlienta(Adres adresKlienta) {
        this.adresKlienta = adresKlienta;
    }

    Klient(String imie, String nazwisko, ArrayList<Zamowienie> listaZamowien, Adres adresKlienta){
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.listaZamowien=listaZamowien;
        this.adresKlienta=adresKlienta;
    }

    public void dodajZamowienie(Zamowienie singleOrder){
        listaZamowien.add(singleOrder);
    }

    public void wyswietlHistorieZamowien(){
        for(int i = 0; i<listaZamowien.size(); i++){
            System.out.println("{\nZamowienie "+ (i+1) +" :");
            listaZamowien.get(i).wyswietlZamowienie();
            System.out.println("}");
        }
    }
    public double obliczLacznyKosztZamowien(){
        double lacznie = 0;
        for (int i = 0; i < listaZamowien.size(); i++) {
            lacznie += listaZamowien.get(i).getKoszykZakupowy().obliczCalkowitaWartosc();
        }
        return lacznie;
    }
    @Override
    public String toString() {
        return "imie: "+imie+", nazwisko: "+nazwisko;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Klient klient = (Klient) o;
        return Objects.equals(imie, klient.imie) && Objects.equals(nazwisko, klient.nazwisko) && Objects.equals(adresKlienta, klient.adresKlienta);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imie, nazwisko, adresKlienta);
    }
}
