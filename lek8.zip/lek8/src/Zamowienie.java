public class Zamowienie {

    private KoszykZakupowy koszykZakupowy;
    private String statusZamowienia;
    private Platnosc platnosc;

    KoszykZakupowy getKoszykZakupowy() {
        return koszykZakupowy;
    }

    public void setKoszykZakupowy(KoszykZakupowy koszykZakupowy) {
        this.koszykZakupowy = koszykZakupowy;
    }

    public void setStatusZamowienia(String statusZamowienia) {
        this.statusZamowienia = statusZamowienia;
    }

    public Platnosc getPlatnosc() {
        return platnosc;
    }

    public void setPlatnosc(Platnosc platnosc) {
        this.platnosc = platnosc;
    }

    public String getStatusZamowienia() {
        return statusZamowienia;
    }

    Zamowienie(KoszykZakupowy koszykZakupowy,String statusZamowienia){
        this.koszykZakupowy=koszykZakupowy;
        this.statusZamowienia=statusZamowienia;
        this.platnosc = new Platnosc(this.koszykZakupowy.obliczCalkowitaWartosc(), "nieoplacone");
    }
    public void ustawStatusZamowienia(String status){
        this.statusZamowienia=status;
    }
    public void wyswietlZamowienie(){
        System.out.println("Zamowienie zawiera: ");
        koszykZakupowy.wyswietlZawartoscKoszyka();
        System.out.println("Status: "+statusZamowienia);
    }
    public void finalizujZamowienie(){
        if (platnosc.getStatusPlatnosci().equals("oplacone"))
            this.ustawStatusZamowienia("Gotowe do wysylki");

    }
    public void zwrocProdukt(Produkt produkt, int ilosc){
        for (int i=0;i<ilosc;i++) {
            this.koszykZakupowy.getListaProdukt().remove(produkt);

        }
        produkt.setIloscNaMagazynie(produkt.getIloscNaMagazynie()+ilosc);
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("zamowienie zawiera: ").append(koszykZakupowy.toString()).append("\n").append("status zamowienia: ").append(statusZamowienia).append("\n").append("\n");
        return sb.toString();
    }

}
