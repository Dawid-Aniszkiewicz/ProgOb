import java.time.LocalDate;
import java.util.ArrayList;

public class Sklep {
    private ArrayList<Produkt> produkty;
    private String nazwaSklepu;
    private LocalDate dataPowstania;
    private Magazyn magazynSklepu;


    public ArrayList<Produkt> getProdukty() {
        return produkty;
    }

    public void setProdukty(ArrayList<Produkt> produkty) {
        this.produkty = produkty;
    }

    public String getNazwaSklepu() {
        return nazwaSklepu;
    }

    public void setNazwaSklepu(String nazwaSklepu) {
        this.nazwaSklepu = nazwaSklepu;
    }

    public LocalDate getDataPowstania() {
        return dataPowstania;
    }

    public void setDataPowstania(LocalDate dataPowstania) {
        if (dataPowstania.isBefore(LocalDate.now())) {
            this.dataPowstania = dataPowstania;
        }
        else throw new IllegalArgumentException("The given date cannot be in the future");
    }

    public Magazyn getMagazynSklepu() {
        return magazynSklepu;
    }

    public void setMagazynSklepu(Magazyn magazynSklepu) {
        this.magazynSklepu = magazynSklepu;
    }

    Sklep(ArrayList<Produkt> produkty, String nazwaSklepu, LocalDate dataPowstania){
        if (dataPowstania.isBefore(LocalDate.now())) {
            this.produkty = produkty;
            this.nazwaSklepu = nazwaSklepu;
            this.dataPowstania = dataPowstania;
        }
        else throw new IllegalArgumentException("The given date cannot be in the future");
    }

    public void dodajProdukt(Produkt singleProduct){
        produkty.add(singleProduct);
    }
    public void wyswietlOferty(){
        for (Produkt item : produkty) {
            System.out.print(item.getNazwa() +", ");
        }
    }
    public Produkt wyszukajProduktu(String nazwa){
        for (Produkt item : produkty) {
            if(item.getNazwa().equals(nazwa)){
                return item;
            }
        }
        return null;
    }
    public void zakupy(Produkt singleProduct, Klient osoba, int ilosc){
        if (singleProduct.getIloscNaMagazynie() >=ilosc){
            osoba.getListaZamowien().getLast().getKoszykZakupowy().dodajProdukt(singleProduct, ilosc);
        }

    }


}
