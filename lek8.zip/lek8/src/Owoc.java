public abstract class Owoc {

    public abstract void Smak();
    public abstract void Umyj();
    public abstract void Zjedz();


}

//class Jablko extends Owoc {
//    public void Smak() {
//        System.out.println("Jablko smak");
//    }
//
//    public void Umyj() {
//        System.out.println("Umyj jablko");
//    }
//
//    public void Zjedz() {
//        System.out.println("Zjedz jablko");
//    }
//}
class main {
    public static void main(String[] args) {
        //Owoc Jablko = new Jablko();
        //Jablko.Smak();
        //Jablko.Umyj();
        //Jablko.Zjedz();
    }
}