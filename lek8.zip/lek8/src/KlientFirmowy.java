import java.util.ArrayList;
import java.util.List;
public class KlientFirmowy extends Klient {
    final String NIP;
    final String REGON;

public KlientFirmowy(String imie, String nazwisko, List<Zamowienie>listaZamowien,Adres adresKlienta, String NIP, String REGON) {
super(imie,nazwisko, (ArrayList<Zamowienie>) listaZamowien, adresKlienta);
this.NIP=NIP;
this.REGON=REGON;
}
}