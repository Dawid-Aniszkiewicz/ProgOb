import java.util.HashMap;

public class KoszykZakupowy {

    private HashMap<Produkt, Integer> listaProdukt;
    //    private ArrayList<Produkt> listaProduktow;
    /*KoszykZakupowy(){
        listaProduktow=new ArrayList<Produkt>();

    }*/
    KoszykZakupowy(){
        this.listaProdukt = new HashMap<>();
    }
    /*public ArrayList<Produkt> getListaProduktow() {
        return listaProduktow;
    }

    public void setListaProduktow(ArrayList<Produkt> listaProduktow) {
        this.listaProduktow = listaProduktow;
    }*/

    public HashMap<Produkt, Integer> getListaProdukt() {
        return listaProdukt;
    }

    public void setListaProdukt(HashMap<Produkt, Integer> listaProdukt) {
        this.listaProdukt = listaProdukt;
    }

    public void dodajProdukt(Produkt item, int ilosc){
        if(item.getIloscNaMagazynie() >ilosc){
            listaProdukt.put(item,ilosc);
            item.setIloscNaMagazynie(item.getIloscNaMagazynie()-ilosc);
        }
    }
    public void wyswietlZawartoscKoszyka(){
        for (Produkt item: listaProdukt.keySet()){
            System.out.println("przedmiot: "+item.getNazwa()+", ilosc: "+listaProdukt.get(item));
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Produkt item: listaProdukt.keySet()){
            sb.append("przedmiot: ").append(item.getNazwa()).append(", ilosc: ").append(listaProdukt.get(item)).append("\n");
        }
        return sb.toString();
    }

    /*public void wyswietlZawartoscKoszyka(){
        ArrayList<Produkt> widziane = new ArrayList<>();
        for(Produkt item:listaProduktow){
            if(!widziane.contains(item)){
                widziane.add(item);
            }

        }
        for(Produkt item:widziane){
            System.out.println("Nazwa: "+ item.getNazwa() +"\nilosc: "+iloscWKoszyku(item));
        }
    }*/
    /*private int iloscWKoszyku(Produkt przedmiot){
        int count=0;
        for(Produkt item:listaProduktow){
            if(item.equals(przedmiot))
                count++;
        }
        return count;
    }*/
    public double obliczCalkowitaWartosc(){
        double suma=0;
        for(Produkt item:listaProdukt.keySet()){
            suma+= item.getCena();
        }
        return suma;
    }

}
