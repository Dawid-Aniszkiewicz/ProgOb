import java.util.ArrayList;

class Animal{
    String name;
    String breed;

    public Animal(String name, String breed) {
        this.name = name;
        this.breed = breed;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
class Dog extends Animal{
    private int age;
    public Dog(String name, String breed, int age) {
        super(name, breed);
        this.age = age;
    }
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "age=" + age +
                ", name='" + name + '\'' +
                ", breed='" + breed + '\'' +
                '}';
    }
}
class Pair<T>{
    T first;
    T second;

    public Pair(T first, T second) {
        this.first = first;
        this.second = second;
    }

    @Override
    public String toString() {
        return "Pair{" +
                "first=" + first +
                ", second=" + second +
                '}';
    }
}

public class Main {
//    public static <T extends Animal>T findMax(T a1, T a2) {
//        if(a1.getAge() > a2.getAge()) {
//            return a1;
//        }
//        return a2;
//    }
    public static <T>void findMinMaxAge(Dog[] tab, Pair<?super Dog>result){
    Dog min =tab[0];
    Dog max =tab[0];
    for(Dog d:tab){
        if(d.getAge()<max.getAge()){
            max=d;
        }
        if(d.getAge()>min.getAge()){
            min=d;
        }

    }
    result.first=min;
    result.second=max;
    }
    public static void main(String[] args) {
        Dog d1 = new Dog("Bob", "czarny", 10);
        Dog d2 = new Dog("Rob", "bialy", 12);
        Dog d3 = new Dog("Robert", "bialy2", 14);


       // System.out.println((findMax(d1,d2)).age);
        Dog[]dogs = new Dog[]{d1,d2,d3};
        Pair<Dog>dPair = new Pair<>(null,null);
        findMinMaxAge(dogs, dPair);
        System.out.println(dPair);
    }
}
