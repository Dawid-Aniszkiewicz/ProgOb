import java.util.ArrayList;
import java.util.List;

class Box<T>{
    T obiekt;


    public T getObiekt() {
        return obiekt;
    }

    public Box(T obiekt) {
        this.obiekt = obiekt;
    }

    public void setObiekt(T obiekt) {
        this.obiekt = obiekt;
    }
}
class Counter<T>{
    List<T> lista = new ArrayList<T>();

    public void add(T obiekt){
        lista.add(obiekt);
    }
    public int getCount(){
        return lista.size();
    }
}

public class Zad1 {
    public static <T> boolean isEqual(T a, T b) {
        return a.equals(b);
    }
    public static void main(String[] args) {
        Box<String>b1= new Box<>(null);
        b1.setObiekt("rudy");
        System.out.println(b1.getObiekt());

        Box<String>b2= new Box<>(null);
        b2.setObiekt("rudzik");
        System.out.println(b2.getObiekt());
        System.out.println(isEqual(b1.getObiekt(), b2.getObiekt()));
    }
}
